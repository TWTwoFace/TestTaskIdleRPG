﻿public class EntityAttackFightPhase : EntityFightPhase
{
    public EntityAttackFightPhase(float timeToAction) : base(timeToAction)
    {

    }
}

