﻿
public class EntityCooldownFightPhase : EntityFightPhase
{
    public EntityCooldownFightPhase(float timeToAction) : base(timeToAction)
    {

    }
}

