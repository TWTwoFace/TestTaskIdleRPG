﻿
public class EntitySwitchWeaponFightPhase : EntityFightPhase
{
    public EntitySwitchWeaponFightPhase(float timeToAction) : base(timeToAction)
    {

    }
}

