using UnityEngine;

public class PlayerIdleBehaviour : BehaviourState
{

}
